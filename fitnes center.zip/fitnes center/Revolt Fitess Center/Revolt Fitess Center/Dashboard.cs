﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revolt_Fitess_Center
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();

            f1.Show();

            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            New_Admission n1 = new New_Admission();

            n1.Show();

            this.Hide();
        }

        private void lLogout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Environment.Exit(0);

           Form1 f1 = new Form1();

            f1.Show();

            this.Hide();
        }
    }
}
