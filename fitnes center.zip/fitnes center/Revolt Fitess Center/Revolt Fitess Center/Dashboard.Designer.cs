﻿namespace Revolt_Fitess_Center
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lLogout = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.btnNewEquipments = new System.Windows.Forms.Button();
            this.btnNewAdmission = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.lLogout);
            this.panel1.Controls.Add(this.label1);
            this.panel1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Location = new System.Drawing.Point(1, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(842, 120);
            this.panel1.TabIndex = 0;
            // 
            // lLogout
            // 
            this.lLogout.AutoSize = true;
            this.lLogout.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lLogout.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lLogout.LinkColor = System.Drawing.Color.White;
            this.lLogout.Location = new System.Drawing.Point(11, 19);
            this.lLogout.Name = "lLogout";
            this.lLogout.Size = new System.Drawing.Size(59, 16);
            this.lLogout.TabIndex = 1;
            this.lLogout.TabStop = true;
            this.lLogout.Text = "Logout";
            this.lLogout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lLogout_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label1.Location = new System.Drawing.Point(357, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "DASHBOARD";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.btnNewEquipments);
            this.panel2.Controls.Add(this.btnNewAdmission);
            this.panel2.Controls.Add(this.btnHome);
            this.panel2.Location = new System.Drawing.Point(1, 120);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(237, 341);
            this.panel2.TabIndex = 1;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button4.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(52, 224);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(134, 30);
            this.button4.TabIndex = 3;
            this.button4.Text = "PAYMENT";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // btnNewEquipments
            // 
            this.btnNewEquipments.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnNewEquipments.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewEquipments.Location = new System.Drawing.Point(52, 164);
            this.btnNewEquipments.Name = "btnNewEquipments";
            this.btnNewEquipments.Size = new System.Drawing.Size(139, 29);
            this.btnNewEquipments.TabIndex = 2;
            this.btnNewEquipments.Text = "ADD TRAINERS";
            this.btnNewEquipments.UseVisualStyleBackColor = false;
            // 
            // btnNewAdmission
            // 
            this.btnNewAdmission.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnNewAdmission.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewAdmission.Location = new System.Drawing.Point(52, 107);
            this.btnNewAdmission.Name = "btnNewAdmission";
            this.btnNewAdmission.Size = new System.Drawing.Size(139, 29);
            this.btnNewAdmission.TabIndex = 1;
            this.btnNewAdmission.Text = "NEW ADDMISSION";
            this.btnNewAdmission.UseVisualStyleBackColor = false;
            this.btnNewAdmission.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnHome.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnHome.Location = new System.Drawing.Point(52, 44);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(134, 30);
            this.btnHome.TabIndex = 0;
            this.btnHome.Text = "HOME";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.Location = new System.Drawing.Point(234, 120);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(609, 341);
            this.panel3.TabIndex = 2;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 460);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnNewEquipments;
        private System.Windows.Forms.Button btnNewAdmission;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.LinkLabel lLogout;
    }
}