﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revolt_Fitess_Center
{
    public partial class Form1 : Form
    {
        Dashboard f1 = new Dashboard();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user = txtuName.Text;
            int pass = int.Parse(txtPassword.Text);

            txtuName.Focus();

            if (user == "Admin" && pass.Equals(123))
            {

                MessageBox.Show(" You can now log into the system");

                f1.Show();

                this.Hide();
            }
            else
            {
                MessageBox.Show(" invalid information");

            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtuName.Clear();
            txtPassword.Clear();
            txtuName.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}