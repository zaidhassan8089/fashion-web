﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Revolt_Fitess_Center
{
    public partial class New_Admission : Form
    {
        public New_Admission()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-73Q3NRQ\SQLEXPRESS01;Initial Catalog=RevoltFitnessStudio;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();
        private string Gender;

        public New_Admission(string gender)
        {
            Gender = gender;
        }

        public string gender { get; private set; }
        
        private void btnRegister_Click(object sender, EventArgs e)
        {

            string gender;
            if (rbtnMale.Checked)
            {
                gender = "male";
            }
            else
            {
                gender = "female";
            }
            con.Open();

            string query = "INSERT INTO RevoltFitnessStudio (RegNo, FirstName, LastName, DateofBirth, Gender, Address, Email, MobilePhone, HomePhone, ParentName, NIC, ContactNumber) " +
                           "VALUES ('" + cmbRegNo.Text + "','" + txtfName.Text + "','" + txtlName.Text + "','" + dateTimePicker2.Value.ToString() + "','" + gender + "','" + txtAddress.Text + "','" + txtEmail.Text + "','" + txtmPhone.Text + "','" + txthPhone.Text + "','" + txtpName.Text + "','" + txtNIC.Text + "','" + txtcNumber.Text + "')";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Record is added to the table", "Adding a new record", MessageBoxButtons.OK, MessageBoxIcon.Information);
            con.Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {


            string Gender = "";

            if (rbtnMale.Checked)
            {
                Gender = "male";
            }
            else
            {
                Gender = "female";
            }

            con.Open();
            string sqlupdate = "update RevoltFitnessStudio set FirstName='" + txtfName.Text + "', LastName='" + txtlName.Text + "', DateofBirth='" + dateTimePicker2.Value.ToString() + "', Gender='" + Gender + "', Address='" + txtAddress.Text + "', Email='" + txtEmail.Text + "', MobilePhone='" + txtmPhone.Text + "', HomePhone='" + txthPhone.Text + "', ParentName='" + txtpName.Text + "', NIC='" + txtNIC.Text + "', ContactNumber='" + txtcNumber.Text + "' where RegNo='" + cmbRegNo.Text + "'";

            SqlCommand cmd = new SqlCommand(sqlupdate, con);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Amendments are saved in the table", "Editing an existing record", MessageBoxButtons.OK, MessageBoxIcon.Information);
            con.Close();


        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtfName.Clear();
            txtlName.Clear();
            // dateTimePicker2.
            //  gender.Clear(); 
            txtAddress.Clear();
            txtEmail.Clear();
            txtmPhone.Clear();
            txthPhone.Clear();
            txtpName.Clear();
            txtNIC.Clear();
            txtcNumber.Clear();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();
            string sqldelete = ("delete from RevoltFitnessStudio where RegNo='" + cmbRegNo.Text + "' ");

            cmd = new SqlCommand(sqldelete, con);
            cmd.ExecuteNonQuery();

            MessageBox.Show(" Record id delete suucesfully", "Deleting a record", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.Close();
        }

        private void lExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void cmbRegNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sqlcombo = "SELECT * FROM RevoltFitnessStudio WHERE RegNo = '" + cmbRegNo.Text + "'";
            SqlCommand cmd = new SqlCommand(sqlcombo, con);
            SqlDataReader dr;

            con.Open();
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                cmbRegNo.Text = dr["RegNo"].ToString();
                txtfName.Text = dr["FirstName"].ToString();
                txtlName.Text = dr["LastName"].ToString();
                dateTimePicker2.Value = Convert.ToDateTime(dr["DateofBirth"]); // Ensure to convert DateofBirth to DateTime
                string gender = dr["Gender"].ToString();

                txtAddress.Text = dr["Address"].ToString(); // Corrected field name
                txtEmail.Text = dr["Email"].ToString();
                txtmPhone.Text = dr["MobilePhone"].ToString();
                txthPhone.Text = dr["HomePhone"].ToString();
                txtpName.Text = dr["ParentName"].ToString();
                txtNIC.Text = dr["NIC"].ToString();
                txtcNumber.Text = dr["ContactNumber"].ToString();

                if (gender == "female")
                {
                    rbtnFemale.Checked = true;
                }
                else if (gender == "male")
                {
                    rbtnMale.Checked = true;
                }
            }

            con.Close();


        }

        private void genderstring()
        {
            throw new NotImplementedException();
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void txtcNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNIC_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void txtpName_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void txthPhone_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txtmPhone_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void rbtnFemale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtnMale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void txtlName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtfName_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnfemale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnmale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
